package al.academy.ikubinfo.bootcamp.abstraction.examples;

public class Motorr extends MjetTransporti {

	@Override
	public void start() {
		// TODO Auto-generated method stub

	}

	@Override
	public void leviz() {
		// TODO Auto-generated method stub

	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub

	}

}
