package al.academy.ikubinfo.bootcamp.abstraction.examples;

import  al.academy.ikubinfo.bootcamp.abstraction.interfaces.Nderfaqe2;

public class KlasaImpl implements Nderfaqe1 {

}
