package al.academy.ikubinfo.bootcamp.abstraction.examples;

public abstract class Telefon {

	public abstract void ngrejVolum();

	public abstract void ulVolum();

	public abstract void bejTelefonate();

	public abstract void lexoMesazh();

	public abstract void dergoMesazh();
}
