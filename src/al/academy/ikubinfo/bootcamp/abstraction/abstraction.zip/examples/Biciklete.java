package al.academy.ikubinfo.bootcamp.abstraction.examples;

public class Biciklete extends MjetTransporti {

	@Override
	public void start() {
		System.out.println("asgje");
		
		

	}

	@Override
	public void leviz() {
		// TODO Auto-generated method stub

	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub

	}

}
