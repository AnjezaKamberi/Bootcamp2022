package al.academy.ikubinfo.bootcamp.abstraction.examples;

public class Samsung extends Telefon {

	@Override
	public void ngrejVolum() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void ulVolum() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void bejTelefonate() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void lexoMesazh() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void dergoMesazh() {
		// TODO Auto-generated method stub
		
	}

}
