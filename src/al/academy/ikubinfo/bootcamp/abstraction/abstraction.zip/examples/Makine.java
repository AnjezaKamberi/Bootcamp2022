package al.academy.ikubinfo.bootcamp.abstraction.examples;

public class Makine extends MjetTransporti {

	@Override
	public void start() {

	}

	@Override
	public void leviz() {
		// TODO Auto-generated method stub

	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub

	}

	@Override
	public int getNrRrota() {
		// TODO Auto-generated method stub
		return 0;
	}

}
