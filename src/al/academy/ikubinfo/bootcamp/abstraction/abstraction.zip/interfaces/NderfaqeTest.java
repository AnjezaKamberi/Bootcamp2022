package al.academy.ikubinfo.bootcamp.abstraction.interfaces;

public interface NderfaqeTest extends Nderfaqe2, Nderfaqe1 {

	// 
}
