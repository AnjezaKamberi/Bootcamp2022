package al.academy.ikubinfo.bootcamp.abstraction.interfaces;

public class KlasaImplementuese implements InterfaceExample, Nderfaqe1 {

	@Override
	public void metodaPare() {
	}

	@Override
	public void metodaDyte() {
		// TODO Auto-generated method stub

	}

}
