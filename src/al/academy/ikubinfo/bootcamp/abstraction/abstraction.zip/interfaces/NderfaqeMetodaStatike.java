package al.academy.ikubinfo.bootcamp.abstraction.interfaces;

public class NderfaqeMetodaStatike {

	static void printoKurs() {
		System.out.println("Bootcamp Java 2022");
	}
}
