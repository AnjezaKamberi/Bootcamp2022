package al.academy.ikubinfo.bootcamp.abstraction.interfaces;

public interface InstanceVariables {

	int SECOND_BOOTCAMP_JAVA_YEAR = 2022;
	static boolean ACTIVE = true;
	static final String DITA_PARE_KURSIT = "E hene";
	public static final String DITA_DYTE_KURSIT = "E enjte";

	// private String ORE_PAVARUR = "Ore e pavarur";
	// protected String ORE_PAVARUR = "Ore e pavarur";
	// static String ORE_PAVARUR;
	// final String ORE_PAVARUR;;
}
