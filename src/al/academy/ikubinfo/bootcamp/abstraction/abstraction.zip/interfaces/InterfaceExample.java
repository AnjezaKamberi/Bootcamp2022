package al.academy.ikubinfo.bootcamp.abstraction.interfaces;

interface InterfaceExample {

	void metodaPare();
	void metodaDyte();
}
