package al.academy.ikubinfo.bootcamp.abstraction.interfaces;

public abstract class KlasaImplementueseNderfaqeMetodaDefault implements NderfaqeMetodaDefault {

	public abstract int getVlereNumerike();
}
