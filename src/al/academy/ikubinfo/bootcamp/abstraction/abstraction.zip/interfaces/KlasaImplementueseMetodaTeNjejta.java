package al.academy.ikubinfo.bootcamp.abstraction.interfaces;

public class KlasaImplementueseMetodaTeNjejta implements Nderfaqe1, Nderfaqe2 {

	@Override
	public void metodaPare() {

		System.out.println("implementimi i metodes se pare qe eshte e njejte ne dy nderfaqe");
	}

}
