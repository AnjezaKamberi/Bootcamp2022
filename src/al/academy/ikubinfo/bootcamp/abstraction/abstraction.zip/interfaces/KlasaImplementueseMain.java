package al.academy.ikubinfo.bootcamp.abstraction.interfaces;

public class KlasaImplementueseMain {

	public static void main(String[] args) {

		Nderfaqe1 objNderfaqe1 = new KlasaImplementueseMetodaTeNjejta();
		objNderfaqe1.metodaPare();

		Nderfaqe2 objNderfaqe2 = new KlasaImplementueseMetodaTeNjejta();
		objNderfaqe2.metodaPare();
	}

}
