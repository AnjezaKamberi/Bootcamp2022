package al.academy.ikubinfo.bootcamp.abstraction.interfaces;

public //abstract 
interface NderfaqeMetodaDeklarim {

	void metoda1();

	abstract void metoda2();

	public abstract void metoda3();
	
	// deklarim i gabuar
	
	final void metoda4();
	
	protected void metoda5();
	
	private final void metoda6();
}
