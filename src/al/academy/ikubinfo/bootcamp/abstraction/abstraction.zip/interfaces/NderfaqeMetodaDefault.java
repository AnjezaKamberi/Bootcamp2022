package al.academy.ikubinfo.bootcamp.abstraction.interfaces;

public interface NderfaqeMetodaDefault {

	public default int getVlereNumerike() {
		return 1;
	}
}
