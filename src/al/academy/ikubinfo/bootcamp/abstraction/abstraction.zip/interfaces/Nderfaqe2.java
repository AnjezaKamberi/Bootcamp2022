package al.academy.ikubinfo.bootcamp.abstraction.interfaces;

public interface Nderfaqe2 {

	void metodaPare();
}
