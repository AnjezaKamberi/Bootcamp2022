package al.academy.ikubinfo.bootcamp.abstraction.interfaces;

interface Nderfaqe1 {

	void metodaPare();
}
 