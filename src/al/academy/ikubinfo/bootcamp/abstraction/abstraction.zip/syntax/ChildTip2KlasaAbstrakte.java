package al.academy.ikubinfo.bootcamp.abstraction.syntax;

public class ChildTip2KlasaAbstrakte extends KlasaAbstrakte {

}
