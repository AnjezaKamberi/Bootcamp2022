package al.academy.ikubinfo.bootcamp.abstraction.syntax;

public class KlasaPrivateKonstruktor {

	private KlasaPrivateKonstruktor() {
		
	}
}
