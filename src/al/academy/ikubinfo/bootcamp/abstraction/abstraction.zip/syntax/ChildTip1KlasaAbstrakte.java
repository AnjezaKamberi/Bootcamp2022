package al.academy.ikubinfo.bootcamp.abstraction.syntax;

public abstract class ChildTip1KlasaAbstrakte extends KlasaAbstrakte {

}
