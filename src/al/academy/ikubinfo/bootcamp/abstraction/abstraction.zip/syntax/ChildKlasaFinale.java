package al.academy.ikubinfo.bootcamp.abstraction.syntax;

public class ChildKlasaFinale extends KlasaFinal {

}
