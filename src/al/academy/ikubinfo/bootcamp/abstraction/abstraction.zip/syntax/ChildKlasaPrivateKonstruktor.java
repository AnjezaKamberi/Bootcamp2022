package al.academy.ikubinfo.bootcamp.abstraction.syntax;

public class ChildKlasaPrivateKonstruktor extends KlasaPrivateKonstruktor {

}
