package al.academy.ikubinfo.bootcamp.abstraction;

public abstract class KlasaAbstrakte {

	
	private String variabli1;
	private int variabli2;
	
	
	public abstract String getVariabli1();
	
	public String getVariabli2() {
		return "";
	}
	
}
